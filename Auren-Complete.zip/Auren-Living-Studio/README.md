# Auren — AI Personal Operating System

A local, working project that combines an immersive room interface with practical personal-management tools.

## Included features
- Room-inspired full-screen interface built with HTML, CSS and CSS shapes (no room background image).
- Natural-language task capture with basic extraction of priority, duration and simple due dates.
- Persistent task management: create, complete, delete, priority, duration and deadline.
- Goal shelf: create and delete goals with descriptions and target dates.
- Daily planner: creates a schedule from unfinished tasks using priority, deadline, duration and available hours, with breaks and unscheduled-task feedback.
- Replanning: rebuilds a schedule from the current unfinished task list.
- Focus timer (browser-local countdown).
- Reflection journal saved to SQLite.
- Insights based on actual task, goal and reflection records.
- FastAPI backend and SQLite database; no paid API key required.

## Requirements
- Python 3.10+
- Internet connection only if you want the optional Google Fonts to load; the app works without them.

## Run on Windows
1. Extract the ZIP.
2. Open the extracted `Auren-Living-Studio` folder in VS Code.
3. Open Terminal and run:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --reload
```

4. Open a second terminal in the same folder and run:

```powershell
python -m http.server 5500 --directory frontend
```

5. Visit `http://127.0.0.1:5500`.

## Run on macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.main:app --reload
```
In a second terminal:
```bash
python3 -m http.server 5500 --directory frontend
```
Then visit `http://127.0.0.1:5500`.

## API documentation
With the backend running, visit `http://127.0.0.1:8000/docs`.

## Try these prompts
- `Add revise NLP tomorrow high priority 45 minutes`
- `Add finish assignment today 60 minutes`
- `I feel overwhelmed`
- `Plan my day`
- `Replan my day`

## Important project honesty
This is a complete local prototype / academic project implementation with a rule-based language parser and deterministic scheduling heuristic. It does **not** claim to use a trained LLM, machine-learning recommendation model, live calendar integration, external notifications, voice input or autonomous multi-agent system. Those require separate model/API integrations and testing. The interface labels these limitations rather than pretending they exist.

## Data
SQLite is stored at `backend/auren.db` and is created automatically on first backend start. Keep the backend terminal running while using the website. The browser page and API are served separately, so both terminals must stay open.
