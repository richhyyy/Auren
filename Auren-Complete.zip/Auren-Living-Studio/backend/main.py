"""Auren - AI Personal Operating System (local demo build).
Uses transparent rule-based language parsing and a deterministic planner; no paid API required.
"""
from datetime import datetime, timedelta, date
from pathlib import Path
import re, sqlite3
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DB = Path(__file__).with_name('auren.db')
app = FastAPI(title='Auren Personal OS', version='1.0.0', description='Personal task, goal, planning and reflection assistant')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

@app.on_event('startup')
def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,priority TEXT NOT NULL DEFAULT 'Medium',deadline TEXT,estimated_minutes INTEGER NOT NULL DEFAULT 30,completed INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,completed_at TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,description TEXT,target_date TEXT,created_at TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS reflections(id INTEGER PRIMARY KEY AUTOINCREMENT,body TEXT NOT NULL,mood TEXT,created_at TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)''')

class TaskIn(BaseModel):
    title:str=Field(min_length=1,max_length=240); priority:str='Medium'; deadline:Optional[str]=None; estimated_minutes:int=Field(default=30,ge=1,le=1440)
class GoalIn(BaseModel):
    title:str=Field(min_length=1,max_length=240); description:Optional[str]=None; target_date:Optional[str]=None
class ReflectionIn(BaseModel):
    body:str=Field(min_length=1,max_length=5000); mood:Optional[str]=None
class MessageIn(BaseModel): message:str=Field(min_length=1,max_length=3000)
class PlanIn(BaseModel): start_time:str='09:00'; end_time:str='17:00'; break_minutes:int=Field(default=10,ge=0,le=120)

@app.get('/health')
def health(): return {'status':'ok','service':'auren','version':'1.0.0'}
@app.get('/tasks')
def tasks():
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM tasks ORDER BY completed, CASE priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END, deadline IS NULL, deadline, created_at DESC")]
@app.post('/tasks')
def add_task(x:TaskIn):
    title=x.title.strip()
    if not title: raise HTTPException(400,'Task title cannot be blank')
    if x.priority not in ('Low','Medium','High'): raise HTTPException(400,'Priority must be Low, Medium or High')
    with db() as c:
        cur=c.execute('INSERT INTO tasks(title,priority,deadline,estimated_minutes,created_at) VALUES(?,?,?,?,?)',(title,x.priority,x.deadline,x.estimated_minutes,datetime.now().isoformat(timespec='seconds')))
        return dict(c.execute('SELECT * FROM tasks WHERE id=?',(cur.lastrowid,)).fetchone())
@app.patch('/tasks/{tid}/complete')
def toggle_task(tid:int):
    with db() as c:
        row=c.execute('SELECT completed FROM tasks WHERE id=?',(tid,)).fetchone()
        if not row: raise HTTPException(404,'Task not found')
        done=1-int(row['completed']); c.execute('UPDATE tasks SET completed=?,completed_at=? WHERE id=?',(done,datetime.now().isoformat(timespec='seconds') if done else None,tid))
        return dict(c.execute('SELECT * FROM tasks WHERE id=?',(tid,)).fetchone())
@app.delete('/tasks/{tid}')
def remove_task(tid:int):
    with db() as c:
        cur=c.execute('DELETE FROM tasks WHERE id=?',(tid,))
        if not cur.rowcount: raise HTTPException(404,'Task not found')
    return {'deleted':tid}
@app.get('/goals')
def goals():
    with db() as c: return [dict(x) for x in c.execute('SELECT * FROM goals ORDER BY target_date IS NULL,target_date,created_at DESC')]
@app.post('/goals')
def add_goal(x:GoalIn):
    with db() as c:
        cur=c.execute('INSERT INTO goals(title,description,target_date,created_at) VALUES(?,?,?,?)',(x.title.strip(),x.description,x.target_date,datetime.now().isoformat(timespec='seconds')))
        return dict(c.execute('SELECT * FROM goals WHERE id=?',(cur.lastrowid,)).fetchone())
@app.delete('/goals/{gid}')
def remove_goal(gid:int):
    with db() as c:
        cur=c.execute('DELETE FROM goals WHERE id=?',(gid,))
        if not cur.rowcount: raise HTTPException(404,'Goal not found')
    return {'deleted':gid}
@app.get('/reflections')
def reflections():
    with db() as c: return [dict(x) for x in c.execute('SELECT * FROM reflections ORDER BY created_at DESC LIMIT 30')]
@app.post('/reflections')
def add_reflection(x:ReflectionIn):
    with db() as c:
        cur=c.execute('INSERT INTO reflections(body,mood,created_at) VALUES(?,?,?)',(x.body.strip(),x.mood,datetime.now().isoformat(timespec='seconds')))
        return dict(c.execute('SELECT * FROM reflections WHERE id=?',(cur.lastrowid,)).fetchone())
@app.delete('/reflections/{rid}')
def remove_reflection(rid:int):
    with db() as c: c.execute('DELETE FROM reflections WHERE id=?',(rid,))
    return {'deleted':rid}

@app.post('/planner/generate')
def plan(x:PlanIn):
    try: start=datetime.strptime(x.start_time,'%H:%M'); end=datetime.strptime(x.end_time,'%H:%M')
    except ValueError: raise HTTPException(400,'Use HH:MM time')
    if end<=start: raise HTTPException(400,'End time must be after start time')
    with db() as c: rows=[dict(r) for r in c.execute("SELECT * FROM tasks WHERE completed=0 ORDER BY CASE priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END, deadline IS NULL, deadline, created_at")]
    cursor=start; out=[]; missed=[]
    for t in rows:
        mins=t['estimated_minutes'] or 30; finish=cursor+timedelta(minutes=mins)
        if finish>end: missed.append({'id':t['id'],'title':t['title'],'reason':'Outside the available time window'}); continue
        out.append({'id':t['id'],'title':t['title'],'priority':t['priority'],'start':cursor.strftime('%H:%M'),'end':finish.strftime('%H:%M'),'minutes':mins,'deadline':t['deadline']})
        cursor=finish+timedelta(minutes=x.break_minutes)
    return {'schedule':out,'unscheduled':missed,'available_minutes':int((end-start).total_seconds()/60),'planned_minutes':sum(t['minutes'] for t in out),'note':'Tasks are ordered by priority and deadline. This local build uses a transparent scheduling heuristic, not a trained AI model or live calendar.'}

@app.get('/insights')
def insights():
    with db() as c:
        total=c.execute('SELECT COUNT(*) n FROM tasks').fetchone()['n']; done=c.execute('SELECT COUNT(*) n FROM tasks WHERE completed=1').fetchone()['n']; open_n=total-done
        goals_n=c.execute('SELECT COUNT(*) n FROM goals').fetchone()['n']; refs=c.execute('SELECT COUNT(*) n FROM reflections').fetchone()['n']
        overdue=c.execute("SELECT COUNT(*) n FROM tasks WHERE completed=0 AND deadline IS NOT NULL AND date(deadline)<date('now')").fetchone()['n']
        recent=[dict(r) for r in c.execute('SELECT title,completed,priority,completed_at FROM tasks ORDER BY created_at DESC LIMIT 6')]
    return {'total_tasks':total,'completed_tasks':done,'open_tasks':open_n,'goals':goals_n,'reflections':refs,'overdue_tasks':overdue,'completion_rate':round(done/total*100) if total else 0,'recent':recent}

@app.post('/assistant/understand')
def assistant(x:MessageIn):
    raw=x.message.strip(); s=raw.lower(); now=date.today()
    # Task capture intent, with simple but explicit extraction rules.
    if re.search(r'\b(add|remind me to|i need to|i have to|todo|to-do)\b',s):
        title=re.sub(r'^(please\s+)?(add|remind me to|i need to|i have to|todo|to-do)\s*','',raw,flags=re.I).strip(' .!')
        pr='High' if re.search(r'\b(urgent|important|high priority|asap)\b',s) else ('Low' if 'low priority' in s else 'Medium')
        duration=re.search(r'(\d+)\s*(min|mins|minutes|hour|hours|hr|hrs)\b',s)
        mins=30
        if duration: mins=int(duration.group(1))*(60 if duration.group(2).startswith(('hour','hr')) else 1); title=re.sub(duration.group(0),'',title,flags=re.I).strip(' ,.-')
        deadline=None
        if 'tomorrow' in s: deadline=(now+timedelta(days=1)).isoformat()
        elif 'today' in s: deadline=now.isoformat()
        elif 'next week' in s: deadline=(now+timedelta(days=7)).isoformat()
        elif 'tonight' in s: deadline=now.isoformat()
        title=re.sub(r'\b(today|tomorrow|tonight|next week|urgent|important|high priority|asap|low priority)\b','',title,flags=re.I).strip(' ,.-') or raw
        with db() as c:
            cur=c.execute('INSERT INTO tasks(title,priority,deadline,estimated_minutes,created_at) VALUES(?,?,?,?,?)',(title,pr,deadline,mins,datetime.now().isoformat(timespec='seconds')))
            task=dict(c.execute('SELECT * FROM tasks WHERE id=?',(cur.lastrowid,)).fetchone())
        return {'intent':'capture_task','reply':f"I've added '{title}' to your task list. You can edit its details in the task drawer.",'created_task':task,'engine':'rule_based_nlp'}
    if any(w in s for w in ['replan','missed','reschedule','running late','schedule changed']):
        return {'intent':'replan','reply':'I can rebuild your day from unfinished tasks. Open Plan, set the time you have left, and generate a fresh schedule.','engine':'rule_based_router'}
    if any(w in s for w in ['plan my day','make a plan','schedule my day','organise my day','organize my day']):
        return {'intent':'plan','reply':'Your saved tasks are ready to schedule. Open Plan, choose your available hours, and generate your day.','engine':'rule_based_router'}
    if any(w in s for w in ['overwhelmed','too much','stressed','dont know where','don’t know where']):
        with db() as c: n=c.execute('SELECT COUNT(*) n FROM tasks WHERE completed=0').fetchone()['n']
        return {'intent':'support','reply':f"Let's make this smaller. You have {n} open tasks. Pick one important task, give it a realistic time estimate, and let the planner arrange the rest. You don't need to solve everything at once.",'engine':'rule_based_router'}
    if any(w in s for w in ['progress','insight','how am i doing','analytics']): return {'intent':'insights','reply':'Your progress is based on saved tasks, completed work, goals and reflections. Open Insights to see the current summary.','engine':'rule_based_router'}
    return {'intent':'conversation','reply':'I can capture a task from a sentence, organise saved tasks into a schedule, help replan unfinished work, and show your progress. Try: “Add revise NLP tomorrow high priority 45 minutes”.','engine':'rule_based_router'}
